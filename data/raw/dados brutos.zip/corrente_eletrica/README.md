# Dados de corrente eletrica do um lote de frango inteiro

# regex dos arquivos
corrente_dd_mm-dd_mm.csv (dados de corrente eletrica de dd_mm ate dd_mm)

# existem 4 aviarios nesta granja e os dados estao nestes arquivos

# Datas
Data de Alojamento 07/10/2025 (dd/mm/aaaa) 
Data de Abate 23/11/2025 (dd/mm/aaaa)

# Premissas
- Extrair a idade do lote
- Extrair o intervalo de confiança de corrente para cada dia de criacao de aves
- 
